/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package Baju_preloved;

import java.sql.Connection;
import java.sql.DriverManager;
import javax.swing.JOptionPane;
/**
 *
 * @author erzxn
 */
public class koneksi {
    Connection koneksi;
    public void koneksidb(){
        try {
            Class.forName("com.mysql.cj.jdbc.Driver").newInstance(); 
            System.out.println("Driver JDBC ditemukan");
            try {
                koneksi =
                DriverManager.getConnection("jdbc:mysql://localhost:3306/baju_preloved", "root", "");
                System.out.println("koneksi berhasil");
            } catch (Exception e) {
            System.out.println("koneksi tdk berhasil");
            JOptionPane.showMessageDialog(null, e);
            }
        } catch (Exception e) {
        System.out.println("Driver JDBC tidak ditemukan");
        JOptionPane.showMessageDialog(null, e);
        }
    }
    public static void main(String[] args) {
        koneksi k = new koneksi();
        k.koneksidb();
    }
}
